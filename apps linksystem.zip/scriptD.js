const menu = document.querySelector("#menu");
const menuBtns = document.querySelectorAll(".menu-btn");

menuBtns.forEach((btn) => {
  btn.addEventListener("click", function () {
    menu.classList.toggle("visible");
  });
});

document.addEventListener("click", function (e) {
  if (!menu.contains(e.target) && !menuBtns[0].contains(e.target)) {
    menu.classList.remove("visible");
  }
});

/****************script defilement de carte ******************* */
const cardContainer = document.querySelector('.card-container');
const cards = document.querySelectorAll('.card');
const prevButton = document.getElementById('prevBtn');
const nextButton = document.getElementById('nextBtn');
let isHovered = false; // Variable pour suivre si le curseur est sur l'élément

let currentIndex = 0;
let autoScrollInterval;

function showCard(index) {
  cards.forEach(card => {
    card.style.transform = `translateX(-${index * 100}%)`;
  });
}

function showNextCard() {
  currentIndex = (currentIndex + 1) % cards.length;
  showCard(currentIndex);
}

function showPrevCard() {
  currentIndex = (currentIndex - 1 + cards.length) % cards.length;
  showCard(currentIndex);
}

function startAutoScroll() {
  autoScrollInterval = setInterval(showNextCard, 4000);
}

function stopAutoScroll() {
  clearInterval(autoScrollInterval);
}

nextButton.addEventListener('click', showNextCard);
prevButton.addEventListener('click', showPrevCard);

// Auto-scroll
startAutoScroll(); // Commencez l'autoscroll au chargement de la page

cardContainer.addEventListener('mouseenter', () => {
  isHovered = true;
  stopAutoScroll(); // Arrêtez l'autoscroll lorsque le curseur est sur l'élément
});

cardContainer.addEventListener('mouseleave', () => {
  isHovered = false;
  if (!isHovered) {
    startAutoScroll(); // Reprenez l'autoscroll lorsque le curseur est retiré de l'élément
  }
});


// horloge
let dateContainer = document.querySelector(".date-container");
let clockContainer = document.querySelector(".clock-container");
const weekdays = [
  "Dimanche",
  "Lundi",
  "Mardi",
  "Mercredi",
  "Jeudi",
  "Vendredi",
  "Samedi"
];

const monthNames = [
  "Janvier",
  "Fevrier",
  "Mars",
  "Avril",
  "May",
  "Juin",
  "Juillet",
  "Août",
  "Septembre",
  "Octobre",
  "Novembre",
  "Decembre"
];

const dateClock = setInterval(function () {
  const today = new Date();
  let date = today.getDate();
  let day = weekdays[today.getDay()];
  let month = monthNames[today.getMonth()];

  let hours = today.getHours();
  let minutes = today.getMinutes();

  minutes = minutes < 10 ? "0" + minutes : minutes;

  dateContainer.innerHTML = `<p>${day}</p><span>${date}</span><p>${month}</p>`;

  clockContainer.innerHTML = `${hours}:${minutes}`;
}, 1000);


// JavaScript code to handle the toggle menu
$(document).ready(function() {
  // Hide the menu initially
  $('.dropdown.toggle ul').hide();

  // Toggle the menu when the label is clicked
  $('.dropdown.toggle label').click(function() {
    $('.dropdown.toggle ul').toggle();
  });

  // Close the menu if the user clicks outside of it
  $(document).click(function(event) {
    if (
      $('.dropdown.toggle ul').is(':visible') &&
      !$(event.target).parents('.dropdown.toggle').length
    ) {
      $('.dropdown.toggle ul').hide();
    }
  });
});

//********************************************************table **************************** */

var properties = [
	'name',
	'wins',
	'draws',
	'losses',
	'total',
];

$.each( properties, function( i, val ) {
	
	var orderClass = '';

	$("#" + val).click(function(e){
		e.preventDefault();
		$('.filter__link.filter__link--active').not(this).removeClass('filter__link--active');
  		$(this).toggleClass('filter__link--active');
   		$('.filter__link').removeClass('asc desc');

   		if(orderClass == 'desc' || orderClass == '') {
    			$(this).addClass('asc');
    			orderClass = 'asc';
       	} else {
       		$(this).addClass('desc');
       		orderClass = 'desc';
       	}

		var parent = $(this).closest('.header__item');
    		var index = $(".header__item").index(parent);
		var $table = $('.table-content');
		var rows = $table.find('.table-row').get();
		var isSelected = $(this).hasClass('filter__link--active');
		var isNumber = $(this).hasClass('filter__link--number');
			
		rows.sort(function(a, b){

			var x = $(a).find('.table-data').eq(index).text();
    			var y = $(b).find('.table-data').eq(index).text();
				
			if(isNumber == true) {
    					
				if(isSelected) {
					return x - y;
				} else {
					return y - x;
				}

			} else {
			
				if(isSelected) {		
					if(x < y) return -1;
					if(x > y) return 1;
					return 0;
				} else {
					if(x > y) return -1;
					if(x < y) return 1;
					return 0;
				}
			}
    		});

		$.each(rows, function(index,row) {
			$table.append(row);
		});

		return false;
	});

});

/*test tableau*/

/*****************script dossier ********************/
function showForm(formNumber) {
  const formOverlay = document.getElementById('formOverlay');
  const form = document.getElementById(`form${formNumber}`);

  if (form) {
      form.style.display = 'block';
      formOverlay.style.display = 'flex';

      // Appliquer un effet de zoom
      setTimeout(() => {
          form.style.transform = 'scale(1)';
      }, 10);
  }
}

function closeForm() {
  const formOverlay = document.getElementById('formOverlay');
  const forms = document.querySelectorAll('.form-container form');

  forms.forEach((form) => {
      form.style.transform = 'scale(0.5)';
      setTimeout(() => {
          form.style.display = 'none';
          formOverlay.style.display = 'none';
      }, 300);
  });
}

////////////******************************dropdown formulaire********************** */

function previewImage(input) {
  var logoPreview = document.querySelector('.logo-preview');
  logoPreview.innerHTML = '';
  if (input.files && input.files[0]) {
      var reader = new FileReader();
      reader.onload = function (e) {
          var image = document.createElement('img');
          image.src = e.target.result;
          logoPreview.appendChild(image);
      };
      reader.readAsDataURL(input.files[0]);
  }
}

document.addEventListener("DOMContentLoaded", function () {
// Cachez le formulaire au chargement de la page
var formulaire = document.querySelector(".container");
formulaire.style.transform = "scale(0)";

// Gérez l'événement de clic sur le bouton "Ajouter"
var boutonAjouter = document.getElementById("afficherFormulaire");
boutonAjouter.addEventListener("click", function () {
formulaire.style.transform = "scale(1)";
});

// Gérez l'événement de clic sur le bouton "Fermer"
var boutonFermer = document.createElement("button");
boutonFermer.innerText = "Fermer";
boutonFermer.className = "btn-submit";
formulaire.appendChild(boutonFermer);

boutonFermer.addEventListener("click", function () {
formulaire.style.transform = "scale(0)";
});
});



