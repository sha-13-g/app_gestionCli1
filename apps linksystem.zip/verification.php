<?php
$server = "localhost"; // Adresse du serveur MySQL
$username = "root"; // Nom d'utilisateur MySQL
$password = ""; // Mot de passe MySQL
$database = "BD_LINK"; // Nom de la base de données

// Établir la connexion à la base de données
$conn = new mysqli($server, $username, $password, $database);

// Vérifier la connexion
if ($conn->connect_error) {
    die("La connexion à la base de données a échoué : " . $conn->connect_error);
}

// Récupérer les informations du formulaire
$username = $_POST["username"];
$password = $_POST["password"];

// Échapper les données pour éviter les injections SQL
$username = $conn->real_escape_string($username);
$password = $conn->real_escape_string($password);

// Requête pour vérifier les informations d'identification
$query = "SELECT * FROM users WHERE username = '$username'";
$result = $conn->query($query);

// Vérifier si l'utilisateur a été trouvé
if ($result->num_rows === 1) {
    $row = $result->fetch_assoc();
    $hashedPasswordFromDB = $row["password"];
    if (password_verify($password, $hashedPasswordFromDB)) {
        // L'utilisateur est authentifié
        header("Location: Dashboard.html"); // Redirige vers la page de tableau de bord
        exit; // Assurez-vous de quitter le script après la redirection
    } else {
        // Mot de passe incorrect
        echo "Mot de passe incorrect.";
    }
} else {
    // L'utilisateur n'est pas trouvé
    echo "Utilisateur non trouvé.";
}

// Fermer la connexion
$conn->close();
?>
